import requests
import json

def lambda_handler(event, context):
    # TODO implement
    url = 'http://15.164.168.205:8080'

    s3UploadFileName = event['Records'][0]['s3']['object']['key']

    data = {"file": s3UploadFileName}
    data = json.dumps(data)
    response = requests.post(url,data=data)

    return {
        'statusCode': response.status_code,
        'body': response.text
    }   